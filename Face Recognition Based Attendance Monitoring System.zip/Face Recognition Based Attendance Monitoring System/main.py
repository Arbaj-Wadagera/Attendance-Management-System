############################################# IMPORTING ################################################
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mess
import tkinter.simpledialog as tsd
import cv2,os
import csv
import numpy as np
from PIL import Image
import pandas as pd
import datetime
import time

############################################# FUNCTIONS ################################################

def assure_path_exists(path):
    dir = os.path.dirname(path)
    if not os.path.exists(dir):
        os.makedirs(dir)

##################################################################################

def tick():
    time_string = time.strftime('%H:%M:%S')
    clock.config(text=time_string)
    clock.after(200,tick)

###################################################################################

def contact():
    mess._show(title='Contact us', message="Please contact us on : 'arbaazcsbms@gmail.com' ")

###################################################################################

def check_haarcascadefile():
    exists = os.path.isfile("haarcascade_frontalface_default.xml")
    if exists:
        pass
    else:
        mess._show(title='Some file missing', message='Please contact us for help')
        window.destroy()

###################################################################################

# Constants for the Change Password dialog
CP_BG_WINDOW = "#F0F2F5"
CP_TEXT_COLOR_DARK = "#2C3E50"
CP_ENTRY_BG = "#FFFFFF"
CP_ENTRY_FG = "#34495E"
CP_BUTTON_BG_SAVE = "#2ECC71" # Green
CP_BUTTON_FG_SAVE = "#FFFFFF"
CP_BUTTON_BG_CANCEL = "#E74C3C" # Red
CP_BUTTON_FG_CANCEL = "#FFFFFF"
CP_FONT_LABEL = ('Segoe UI', 11, 'bold')
CP_FONT_ENTRY = ('Segoe UI', 11)
CP_FONT_BUTTON = ('Segoe UI Semibold', 10)

def save_pass():
    assure_path_exists("TrainingImageLabel/")
    exists1 = os.path.isfile("TrainingImageLabel\psd.txt")
    if exists1:
        tf = open("TrainingImageLabel\psd.txt", "r")
        key = tf.read()
    else:
        master.destroy()
        new_pas = tsd.askstring('Old Password not found', 'Please enter a new password below', show='*')
        if new_pas == None:
            mess._show(title='No Password Entered', message='Password not set!! Please try again')
        else:
            tf = open("TrainingImageLabel\psd.txt", "w")
            tf.write(new_pas)
            mess._show(title='Password Registered', message='New password was registered successfully!!')
            return
    op = (old.get())
    newp= (new.get())
    nnewp = (nnew.get())
    if (op == key):
        if(newp == nnewp):
            txf = open("TrainingImageLabel\psd.txt", "w")
            txf.write(newp)
        else:
            mess._show(title='Error', message='Confirm new password again!!!')
            return
    else:
        mess._show(title='Wrong Password', message='Please enter correct old password.')
        return
    mess._show(title='Password Changed', message='Password changed successfully!!')
    master.destroy()

###################################################################################

def change_pass():
    global master
    master = tk.Toplevel(window) # Use Toplevel for a child window
    master.geometry("450x220")
    master.resizable(False,False)
    master.title("Change Password")
    master.configure(background=CP_BG_WINDOW)
    master.grab_set() # Make it modal

    main_frame = tk.Frame(master, bg=CP_BG_WINDOW, padx=20, pady=20)
    main_frame.pack(expand=True, fill=tk.BOTH)

    lbl4 = tk.Label(main_frame,text='Enter Old Password',bg=CP_BG_WINDOW, fg=CP_TEXT_COLOR_DARK, font=CP_FONT_LABEL)
    lbl4.grid(row=0, column=0, sticky='w', pady=(0,5))
    global old
    old=tk.Entry(main_frame,width=30 ,fg=CP_ENTRY_FG, bg=CP_ENTRY_BG, relief='solid', bd=1, font=CP_FONT_ENTRY,show='*')
    old.grid(row=1, column=0, columnspan=2, pady=(0,10), ipady=4)

    lbl5 = tk.Label(main_frame, text='Enter New Password', bg=CP_BG_WINDOW, fg=CP_TEXT_COLOR_DARK, font=CP_FONT_LABEL)
    lbl5.grid(row=2, column=0, sticky='w', pady=(0,5))
    global new
    new = tk.Entry(main_frame, width=30, fg=CP_ENTRY_FG, bg=CP_ENTRY_BG, relief='solid', bd=1, font=CP_FONT_ENTRY,show='*')
    new.grid(row=3, column=0, columnspan=2, pady=(0,10), ipady=4)

    lbl6 = tk.Label(main_frame, text='Confirm New Password', bg=CP_BG_WINDOW, fg=CP_TEXT_COLOR_DARK, font=CP_FONT_LABEL)
    lbl6.grid(row=4, column=0, sticky='w', pady=(0,5))
    global nnew
    nnew = tk.Entry(main_frame, width=30, fg=CP_ENTRY_FG, bg=CP_ENTRY_BG, relief='solid', bd=1, font=CP_FONT_ENTRY,show='*')
    nnew.grid(row=5, column=0, columnspan=2, pady=(0,15), ipady=4)
    
    button_frame = tk.Frame(main_frame, bg=CP_BG_WINDOW)
    button_frame.grid(row=6, column=0, columnspan=2, sticky='ew')
    button_frame.columnconfigure(0, weight=1)
    button_frame.columnconfigure(1, weight=1)

    save1 = tk.Button(button_frame, text="Save", command=save_pass, fg=CP_BUTTON_FG_SAVE, bg=CP_BUTTON_BG_SAVE, height=1, width=15, activebackground=SUCCESS_COLOR_DARK, activeforeground=TEXT_COLOR_LIGHT, font=CP_FONT_BUTTON, relief=tk.FLAT, pady=5)
    save1.grid(row=0, column=0, padx=(0,5), sticky='ew')
    
    cancel=tk.Button(button_frame,text="Cancel", command=master.destroy ,fg=CP_BUTTON_FG_CANCEL,bg=CP_BUTTON_BG_CANCEL ,height=1,width=15 , activebackground=DANGER_COLOR_DARK, activeforeground=TEXT_COLOR_LIGHT, font=CP_FONT_BUTTON, relief=tk.FLAT, pady=5)
    cancel.grid(row=0, column=1, padx=(5,0), sticky='ew')
    
    # master.mainloop() # Not needed for Toplevel if main window is running

#####################################################################################

def psw():
    assure_path_exists("TrainingImageLabel/")
    exists1 = os.path.isfile("TrainingImageLabel\psd.txt")
    if exists1:
        tf = open("TrainingImageLabel\psd.txt", "r")
        key = tf.read()
    else:
        new_pas = tsd.askstring('Old Password not found', 'Please enter a new password below', show='*')
        if new_pas == None:
            mess._show(title='No Password Entered', message='Password not set!! Please try again')
        else:
            tf = open("TrainingImageLabel\psd.txt", "w")
            tf.write(new_pas)
            mess._show(title='Password Registered', message='New password was registered successfully!!')
            return
    password = tsd.askstring('Password', 'Enter Password', show='*')
    if (password == key):
        TrainImages()
    elif (password == None):
        pass
    else:
        mess._show(title='Wrong Password', message='You have entered wrong password')

######################################################################################

def clear():
    txt.delete(0, 'end')
    res = "1)Take Images  >>>  2)Save Profile"
    message1.configure(text=res)


def clear2():
    txt2.delete(0, 'end')
    res = "1)Take Images  >>>  2)Save Profile" # This message seems to be for message1, ensure it's intended for message1 or if message needs updating.
    message1.configure(text=res) # Assuming this is correct based on original

#######################################################################################

def TakeImages():
    check_haarcascadefile()
    columns = ['SERIAL NO.', '', 'ID', '', 'NAME']
    assure_path_exists("StudentDetails/")
    assure_path_exists("TrainingImage/")
    serial = 0
    exists = os.path.isfile("StudentDetails\StudentDetails.csv")
    if exists:
        with open("StudentDetails\StudentDetails.csv", 'r') as csvFile1:
            reader1 = csv.reader(csvFile1)
            for l in reader1:
                serial = serial + 1
        serial = (serial // 2)
        csvFile1.close()
    else:
        with open("StudentDetails\StudentDetails.csv", 'a+') as csvFile1:
            writer = csv.writer(csvFile1)
            writer.writerow(columns)
            serial = 1
        csvFile1.close()
    Id = (txt.get())
    name = (txt2.get())
    if not Id:
        mess.showerror("Input Error", "Please enter an ID.")
        return
    if not name:
        mess.showerror("Input Error", "Please enter a Name.")
        return
        
    if ((name.isalpha()) or (' ' in name)):
        cam = cv2.VideoCapture(0)
        harcascadePath = "haarcascade_frontalface_default.xml"
        detector = cv2.CascadeClassifier(harcascadePath)
        sampleNum = 0
        while (True):
            ret, img = cam.read()
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = detector.detectMultiScale(gray, 1.3, 5)
            for (x, y, w, h) in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                # incrementing sample number
                sampleNum = sampleNum + 1
                # saving the captured face in the dataset folder TrainingImage
                cv2.imwrite("TrainingImage\ " + name + "." + str(serial) + "." + Id + '.' + str(sampleNum) + ".jpg",
                            gray[y:y + h, x:x + w])
                # display the frame
                cv2.imshow('Taking Images (Press Q to quit)', img)
            # wait for 100 miliseconds
            if cv2.waitKey(100) & 0xFF == ord('q'):
                break
            # break if the sample number is morethan 100
            elif sampleNum > 60: # Reduced from 100 to 60 for quicker capture, adjust as needed
                break
        cam.release()
        cv2.destroyAllWindows()
        res = "Images Taken for ID : " + Id
        row = [serial, '', Id, '', name]
        with open('StudentDetails\StudentDetails.csv', 'a+') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(row)
        csvFile.close()
        message1.configure(text=res)
        update_total_registrations()
    else:
        if (name.isalpha() == False):
            res = "Enter Correct name"
            message.configure(text=res) # This is 'message' not 'message1'

########################################################################################

def TrainImages():
    check_haarcascadefile()
    assure_path_exists("TrainingImageLabel/")
    recognizer = cv2.face_LBPHFaceRecognizer.create()
    harcascadePath = "haarcascade_frontalface_default.xml"
    detector = cv2.CascadeClassifier(harcascadePath)
    faces, ID = getImagesAndLabels("TrainingImage")
    try:
        if not faces: # Check if faces list is empty
            mess._show(title='No Images', message='No images found to train. Please take images first.')
            return
        recognizer.train(faces, np.array(ID))
    except Exception as e: # Catch specific cv2 error if possible, or generic Exception
        # print(e) # For debugging
        mess._show(title='Training Error', message='Error during training. Ensure images are available and valid.\n(Maybe no faces registered yet?)')
        return
    recognizer.save("TrainingImageLabel\Trainner.yml")
    res = "Profile Saved Successfully"
    message1.configure(text=res)
    # message.configure(text='Total Registrations till now  : ' + str(ID[0])) # This might be incorrect if ID is empty or not structured as expected.
    update_total_registrations()


############################################################################################3

def getImagesAndLabels(path):
    # get the path of all the files in the folder
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
    # create empth face list
    faces = []
    # create empty ID list
    Ids = []
    # now looping through all the image paths and loading the Ids and the images
    for imagePath in imagePaths:
        # loading the image and converting it to gray scale
        pilImage = Image.open(imagePath).convert('L')
        # Now we are converting the PIL image into numpy array
        imageNp = np.array(pilImage, 'uint8')
        # getting the Id from the image
        try: # Added try-except for robustness in parsing filename
            ID = int(os.path.split(imagePath)[-1].split(".")[1]) # This assumes SerialNo is the ID for training.
        except ValueError:
            print(f"Warning: Could not parse ID from filename: {imagePath}")
            continue # Skip this image
        # extract the face from the training image sample
        faces.append(imageNp)
        Ids.append(ID)
    return faces, Ids

###########################################################################################

def TrackImages():
    check_haarcascadefile()
    assure_path_exists("Attendance/")
    assure_path_exists("StudentDetails/")
    for k in tv.get_children():
        tv.delete(k)
    msg = ''
    i = 0
    j = 0
    recognizer = cv2.face.LBPHFaceRecognizer_create()  # cv2.createLBPHFaceRecognizer()
    exists3 = os.path.isfile("TrainingImageLabel\Trainner.yml")
    if exists3:
        recognizer.read("TrainingImageLabel\Trainner.yml")
    else:
        mess._show(title='Data Missing', message='Trainer data not found. Please Save Profile first!')
        return
    harcascadePath = "haarcascade_frontalface_default.xml"
    faceCascade = cv2.CascadeClassifier(harcascadePath);

    cam = cv2.VideoCapture(0)
    font = cv2.FONT_HERSHEY_SIMPLEX
    col_names = ['Id', '', 'Name', '', 'Date', '', 'Time']
    exists1 = os.path.isfile("StudentDetails\StudentDetails.csv")
    if exists1:
        df = pd.read_csv("StudentDetails\StudentDetails.csv")
    else:
        mess._show(title='Details Missing', message='Students details are missing, please check!')
        cam.release()
        cv2.destroyAllWindows()
        # window.destroy() # Removed to prevent main window close on this error
        return
    
    attendance_marked_today = {} # To keep track of who has been marked today

    while True:
        ret, im = cam.read()
        if not ret:
            mess.showerror("Camera Error", "Failed to grab frame from camera.")
            break
        gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
        faces = faceCascade.detectMultiScale(gray, 1.2, 5, minSize=(100,100)) # Added minSize
        
        current_recognized_person = None # To store current recognized person details

        for (x, y, w, h) in faces:
            cv2.rectangle(im, (x, y), (x + w, y + h), (225, 0, 0), 2)
            serial, conf = recognizer.predict(gray[y:y + h, x:x + w])
            
            if (conf < 60): # Confidence threshold, adjust as needed (lower means more confident)
                ts = time.time()
                date_str = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y')
                timeStamp_str = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
                
                # Match serial (from training, which is StudentDetails CSV Serial No.) with 'SERIAL NO.' in df
                matched_person = df.loc[df['SERIAL NO.'] == serial]

                if not matched_person.empty:
                    aa = matched_person['NAME'].values[0]
                    ID_val = matched_person['ID'].values[0] # This is the Student ID
                    
                    bb = str(aa)
                    current_recognized_person = [str(ID_val), '', bb, '', str(date_str), '', str(timeStamp_str)]
                    
                    # Mark attendance only if not already marked for this person in this session
                    if ID_val not in attendance_marked_today:
                        attendance_marked_today[ID_val] = timeStamp_str # Store timestamp to prevent re-marking immediately

                        # Write to CSV immediately upon recognition for this session
                        date_file_str = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y')
                        attendance_file = f"Attendance/Attendance_{date_file_str}.csv"
                        exists_att_file = os.path.isfile(attendance_file)
                        
                        with open(attendance_file, 'a+', newline='') as csvFile_att:
                            writer_att = csv.writer(csvFile_att)
                            if not exists_att_file or os.path.getsize(attendance_file) == 0:
                                writer_att.writerow(col_names)
                            writer_att.writerow(current_recognized_person)
                        
                        # Update Treeview
                        tv.insert('', 0, text=str(ID_val), values=(bb, date_str, timeStamp_str))

                else: # Serial not found in CSV
                    bb = 'Unknown (DB mismatch)'
            else: # Confidence too low
                Id = 'Unknown'
                bb = str(Id)
            cv2.putText(im, str(bb), (x, y + h + 20), font, 0.8, (255, 255, 255), 2) # Adjusted text position
        
        cv2.imshow('Taking Attendance (Press Q to quit)', im)
        if (cv2.waitKey(1) == ord('q')):
            break

    cam.release()
    cv2.destroyAllWindows()
    
    # Final update of Treeview from today's file (optional, as it's updated live)
    # This part can be removed if live update is sufficient
    ts = time.time()
    date = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y')
    attendance_filename = "Attendance\Attendance_" + date + ".csv"
    if os.path.exists(attendance_filename):
        for k_ in tv.get_children(): # Clear existing before reloading
            tv.delete(k_)
        with open(attendance_filename, 'r') as csvFile1:
            reader1 = csv.reader(csvFile1)
            next(reader1, None) # Skip header
            for lines in reversed(list(reader1)): # Show most recent first
                if len(lines) >= 7:
                    iidd = str(lines[0]) + '   '
                    tv.insert('', 0, text=iidd, values=(str(lines[2]), str(lines[4]), str(lines[6])))
        csvFile1.close()


######################################## MODERN UI CONSTANTS #####################################
BG_WINDOW = "#F0F2F5"
BG_FRAME = "#FFFFFF"
BG_FRAME_HEADER = "#E8EDF0" # Slightly off-white/light gray for headers
TEXT_COLOR_DARK = "#2C3E50"
TEXT_COLOR_LIGHT = "#FFFFFF"
TEXT_COLOR_MUTED = "#566573"
TEXT_COLOR_CLOCK = "#34495E"

PRIMARY_COLOR = "#3498DB"
PRIMARY_COLOR_DARK = "#2874A6"
SUCCESS_COLOR = "#2ECC71"
SUCCESS_COLOR_DARK = "#25A25A"
WARNING_COLOR = "#F39C12"
WARNING_COLOR_DARK = "#C88210"
DANGER_COLOR = "#E74C3C"
DANGER_COLOR_DARK = "#B93E32"

ENTRY_BG = "#FFFFFF"
ENTRY_FG = "#34495E"
ENTRY_BORDER_COLOR = "#BDC3C7"

FONT_PRIMARY_TITLE = ('Segoe UI', 24, 'bold')
FONT_SECTION_TITLE = ('Segoe UI Semibold', 16)
FONT_SUB_TITLE = ('Segoe UI', 13, 'bold')
FONT_LABEL = ('Segoe UI', 11)
FONT_LABEL_BOLD = ('Segoe UI', 11, 'bold')
FONT_BUTTON = ('Segoe UI Semibold', 11)
FONT_ENTRY = ('Segoe UI', 11)
FONT_MESSAGE = ('Segoe UI', 10)
FONT_TREEVIEW_HEADER = ('Segoe UI Semibold', 10)
FONT_TREEVIEW_ROW = ('Segoe UI', 10)
FONT_MENU = ('Segoe UI', 10)
FONT_CLOCK = ('Segoe UI', 14, 'bold')
######################################## USED STUFFS ############################################
    
global key
key = ''

ts = time.time()
date_today_str = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y')
day,month_num,year=date_today_str.split("-")

mont={'01':'January', '02':'February', '03':'March', '04':'April', '05':'May', '06':'June',
      '07':'July', '08':'August', '09':'September', '10':'October', '11':'November', '12':'December'}

######################################## GUI FRONT-END ###########################################

window = tk.Tk()
window.geometry("1280x720")
window.resizable(True,False) # Resizable width, fixed height
window.title("Attendance System")
window.configure(background=BG_WINDOW)

# --- Style for Treeview ---
style = ttk.Style(window)
style.theme_use("clam") # clam, alt, default, classic

style.configure("Treeview.Heading",
                font=FONT_TREEVIEW_HEADER,
                background=PRIMARY_COLOR,
                foreground=TEXT_COLOR_LIGHT,
                padding=(5, 5),
                relief=tk.FLAT)
style.map("Treeview.Heading",
          background=[('active', PRIMARY_COLOR_DARK)])

style.configure("Treeview",
                font=FONT_TREEVIEW_ROW,
                rowheight=int(FONT_TREEVIEW_ROW[1] * 2.8), 
                background=BG_FRAME,
                fieldbackground=BG_FRAME,
                foreground=TEXT_COLOR_DARK,
                relief=tk.SOLID,
                borderwidth=1,
                bordercolor=ENTRY_BORDER_COLOR)
style.map("Treeview",
          background=[('selected', PRIMARY_COLOR_DARK)],
          foreground=[('selected', TEXT_COLOR_LIGHT)])

style.configure("Vertical.TScrollbar", 
                gripcount=0,
                background=PRIMARY_COLOR, 
                darkcolor=PRIMARY_COLOR_DARK, 
                lightcolor=PRIMARY_COLOR,
                troughcolor=BG_FRAME, 
                bordercolor=BG_FRAME, 
                arrowcolor=TEXT_COLOR_LIGHT,
                relief=tk.FLAT,
                arrowsize=14)
style.map("Vertical.TScrollbar",
    background=[('active',PRIMARY_COLOR_DARK)],
    arrowcolor=[('pressed',PRIMARY_COLOR_DARK),('active',PRIMARY_COLOR_DARK)]
)


# --- Top Header Frame for Title, Date, Clock ---
top_header_frame = tk.Frame(window, bg=BG_WINDOW)
top_header_frame.pack(side=tk.TOP, fill=tk.X, pady=(10,0), padx=20)

message3 = tk.Label(top_header_frame, text="Face Recognition Based Attendance Monitoring System" ,fg=TEXT_COLOR_DARK,bg=BG_WINDOW, font=FONT_PRIMARY_TITLE)
message3.pack(side=tk.LEFT, padx=(0, 20))

datetime_frame = tk.Frame(top_header_frame, bg=BG_WINDOW)
datetime_frame.pack(side=tk.RIGHT)

datef = tk.Label(datetime_frame, text = f"{day}-{mont[month_num]}-{year}", fg=TEXT_COLOR_CLOCK,bg=BG_WINDOW, font=FONT_CLOCK)
datef.pack(anchor='ne')

clock = tk.Label(datetime_frame,fg=TEXT_COLOR_CLOCK,bg=BG_WINDOW, font=FONT_CLOCK)
clock.pack(anchor='ne')
tick()

# --- Main Content Area ---
main_content_frame = tk.Frame(window, bg=BG_WINDOW)
main_content_frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=10)
main_content_frame.columnconfigure(0, weight=1, uniform="group1") # Uniform helps in sizing
main_content_frame.columnconfigure(1, weight=0) # For spacing
main_content_frame.columnconfigure(2, weight=1, uniform="group1")
main_content_frame.rowconfigure(0, weight=1)


# --- Frame 1: Attendance ---
frame1 = tk.Frame(main_content_frame, bg=BG_FRAME, relief=tk.RIDGE, bd=2) # Added relief and border
frame1.grid(row=0, column=2, sticky="nsew", padx=(10,0)) # Changed from place to grid
frame1.columnconfigure(0, weight=1)
frame1.rowconfigure(3, weight=1) # For Treeview to expand


head1 = tk.Label(frame1, text="Attendance Log", fg=TEXT_COLOR_DARK, bg=BG_FRAME_HEADER, font=FONT_SECTION_TITLE, anchor='center')
head1.grid(row=0, column=0, columnspan=2, sticky='ew', pady=(10,10), padx=10, ipady=5)

trackImg = tk.Button(frame1, text="Take Attendance", command=TrackImages, fg=TEXT_COLOR_LIGHT, bg=SUCCESS_COLOR, activebackground=SUCCESS_COLOR_DARK, font=FONT_BUTTON, relief=tk.FLAT, padx=10, pady=7)
trackImg.grid(row=1, column=0, columnspan=2, sticky='ew', padx=30, pady=(10,5))

lbl3 = tk.Label(frame1, text="Today's Records",width=20 ,fg=TEXT_COLOR_DARK ,bg=BG_FRAME ,font=FONT_SUB_TITLE)
lbl3.grid(row=2, column=0, columnspan=2, pady=(10,5))

# --- Treeview Frame for better scrollbar placement ---
tv_frame = tk.Frame(frame1, bg=BG_FRAME)
tv_frame.grid(row=3, column=0, sticky='nsew', padx=10, pady=(0,10))
tv_frame.columnconfigure(0, weight=1)
tv_frame.rowconfigure(0, weight=1)

tv= ttk.Treeview(tv_frame, columns = ('name','date','time'), style="Treeview")
tv.column('#0',width=80, anchor='w', stretch=tk.NO)
tv.column('name',width=150, anchor='w')
tv.column('date',width=100, anchor='center')
tv.column('time',width=100, anchor='center')

tv.heading('#0',text ='ID')
tv.heading('name',text ='NAME')
tv.heading('date',text ='DATE')
tv.heading('time',text ='TIME')
tv.grid(row=0,column=0,sticky='nsew')

scroll=ttk.Scrollbar(tv_frame,orient='vertical',command=tv.yview, style="Vertical.TScrollbar")
scroll.grid(row=0,column=1,sticky='ns')
tv.configure(yscrollcommand=scroll.set)

quitWindow = tk.Button(frame1, text="Quit", command=window.destroy, fg=TEXT_COLOR_LIGHT, bg=DANGER_COLOR, activebackground=DANGER_COLOR_DARK, font=FONT_BUTTON, relief=tk.FLAT, padx=10, pady=7)
quitWindow.grid(row=4, column=0, columnspan=2, sticky='ew', padx=30, pady=(10,10))


# --- Frame 2: New Registrations ---
frame2 = tk.Frame(main_content_frame, bg=BG_FRAME, relief=tk.RIDGE, bd=2) # Added relief and border
frame2.grid(row=0, column=0, sticky="nsew", padx=(0,10)) # Changed from place to grid
frame2.columnconfigure(0, weight=1) # For centering content or making it responsive
frame2.columnconfigure(1, weight=0)
frame2.columnconfigure(2, weight=0)


head2 = tk.Label(frame2, text="New Student Registration", fg=TEXT_COLOR_DARK,bg=BG_FRAME_HEADER ,font=FONT_SECTION_TITLE, anchor='center')
head2.grid(row=0,column=0, columnspan=3, sticky='ew', pady=(10,20), padx=10, ipady=5)

# ID Entry
lbl = tk.Label(frame2, text="Enter ID", fg=TEXT_COLOR_DARK,bg=BG_FRAME ,font=FONT_LABEL_BOLD )
lbl.grid(row=1, column=0, columnspan=3, padx=30, pady=(10,2), sticky='sw')

txt_frame = tk.Frame(frame2, bg=BG_FRAME) # Frame for entry and clear button
txt_frame.grid(row=2, column=0, columnspan=3, padx=30, pady=(0,10), sticky='ew')
txt_frame.columnconfigure(0, weight=1)

txt = tk.Entry(txt_frame, fg=ENTRY_FG, bg=ENTRY_BG, font=FONT_ENTRY, relief=tk.SOLID, bd=1)
txt.grid(row=0, column=0, sticky='ew', ipady=4)
txt.insert(0, "") # Placeholder or default

clearButton = tk.Button(txt_frame, text="Clear", command=clear, fg=TEXT_COLOR_LIGHT, bg=WARNING_COLOR, activebackground=WARNING_COLOR_DARK, font=FONT_BUTTON, relief=tk.FLAT, padx=10, pady=4)
clearButton.grid(row=0, column=1, padx=(5,0))

# Name Entry
lbl2 = tk.Label(frame2, text="Enter Name", fg=TEXT_COLOR_DARK,bg=BG_FRAME ,font=FONT_LABEL_BOLD)
lbl2.grid(row=3, column=0, columnspan=3, padx=30, pady=(10,2), sticky='sw')

txt2_frame = tk.Frame(frame2, bg=BG_FRAME) # Frame for entry and clear button
txt2_frame.grid(row=4, column=0, columnspan=3, padx=30, pady=(0,20), sticky='ew')
txt2_frame.columnconfigure(0, weight=1)

txt2 = tk.Entry(txt2_frame, fg=ENTRY_FG, bg=ENTRY_BG,font=FONT_ENTRY, relief=tk.SOLID, bd=1)
txt2.grid(row=0, column=0, sticky='ew', ipady=4)
txt2.insert(0, "") # Placeholder or default

clearButton2 = tk.Button(txt2_frame, text="Clear", command=clear2, fg=TEXT_COLOR_LIGHT, bg=WARNING_COLOR, activebackground=WARNING_COLOR_DARK, font=FONT_BUTTON, relief=tk.FLAT, padx=10, pady=4)
clearButton2.grid(row=0, column=1, padx=(5,0))

# Message for instructions
message1 = tk.Label(frame2, text="1) Take Images  >>>  2) Save Profile" ,bg=BG_FRAME ,fg=TEXT_COLOR_MUTED ,font=FONT_MESSAGE)
message1.grid(row=5, column=0, columnspan=3, padx=30, pady=(0,20), sticky='ew')

# Buttons for actions
takeImg = tk.Button(frame2, text="Take Images", command=TakeImages, fg=TEXT_COLOR_LIGHT, bg=PRIMARY_COLOR, activebackground=PRIMARY_COLOR_DARK, font=FONT_BUTTON, relief=tk.FLAT, padx=10, pady=7)
takeImg.grid(row=6, column=0, columnspan=3, sticky='ew', padx=30, pady=5)

trainImg = tk.Button(frame2, text="Save Profile", command=psw, fg=TEXT_COLOR_LIGHT, bg=PRIMARY_COLOR, activebackground=PRIMARY_COLOR_DARK, font=FONT_BUTTON, relief=tk.FLAT, padx=10, pady=7)
trainImg.grid(row=7, column=0, columnspan=3, sticky='ew', padx=30, pady=5)

# Placeholder for vertical spacing if needed, or add to message padding
spacer_frame = tk.Frame(frame2, height=100, bg=BG_FRAME) # Adjust height as needed for spacing
spacer_frame.grid(row=8, column=0, columnspan=3, sticky='ew')
frame2.rowconfigure(8, weight=1) # Allow this spacer to push 'message' down

# Message for total registrations
message = tk.Label(frame2, text="" ,bg=BG_FRAME ,fg=TEXT_COLOR_DARK, font=FONT_MESSAGE)
message.grid(row=9, column=0, columnspan=3, padx=30, pady=(10,10), sticky='ew')


def update_total_registrations():
    res_count=0
    exists_csv = os.path.isfile("StudentDetails\StudentDetails.csv")
    if exists_csv:
        with open("StudentDetails\StudentDetails.csv", 'r') as csvFile1_reg:
            reader1_reg = csv.reader(csvFile1_reg)
            header = next(reader1_reg, None) # Skip header
            for l_reg in reader1_reg:
                if l_reg: # Check if row is not empty
                    res_count = res_count + 1
        # res_count = (res_count // 2) -1 # Original logic, this seems to assume blank rows or specific structure
                                      # If each student is one row after header, then it's just `res_count`
    message.configure(text='Total Registrations: '+str(res_count))

update_total_registrations() # Initial call


##################### MENUBAR #################################

menubar = tk.Menu(window,relief='flat', bd=0) # Modern flat menubar
filemenu = tk.Menu(menubar,tearoff=0, bg=BG_FRAME, fg=TEXT_COLOR_DARK, font=FONT_MENU, activebackground=PRIMARY_COLOR, activeforeground=TEXT_COLOR_LIGHT)
filemenu.add_command(label='Change Password', command = change_pass)
filemenu.add_command(label='Contact Us', command = contact)
filemenu.add_separator()
filemenu.add_command(label='Exit',command = window.destroy)
menubar.add_cascade(label='Help',font=FONT_MENU,menu=filemenu)

##################### END ######################################

window.configure(menu=menubar)
window.mainloop()

####################################################################################################
